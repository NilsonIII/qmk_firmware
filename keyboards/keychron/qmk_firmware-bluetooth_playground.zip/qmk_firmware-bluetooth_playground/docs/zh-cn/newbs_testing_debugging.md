# 测试和调试

<!---
  original document: 0.15.12:docs/newbs_testing_debugging.md
  git diff 0.15.12 HEAD -- docs/newbs_testing_debugging.md | cat
-->
## 测试

[已移到这里](zh-cn/faq_misc.md#testing)

## 调试 :id=debugging

[已移到这里](zh-cn/faq_debug.md#debugging)

